<div class="aviso-cookies" id="aviso-cookies">
    <img class="galleta" src="img/logoebk.png" alt="Galleta">
    <h3 class="titulo">Cookies</h3>
    <p class="parrafo">Utilizamos cookies propias y de terceros para mejorar nuestros servicios.</p>
    <button class="boton" id="btn-aceptar-cookies">De acuerdo</button>
    <a class="enlace" href="info-cookies.php">Aviso de Cookies</a>
</div>
<div class="fondo-aviso-cookies" id="fondo-aviso-cookies"></div>
