<?php 
    include('layouts/header.php');
?>
<?php 
    include('layouts/menu.php')
?>

<div class="contain"><h1>OOOOOPS! FALLO LA PAGINA! <img src="img/SAD1.png" alt=""> </h1></div>



<?php
    include('layouts/footer.php'); 
?>