<?php 
    include('layouts/header.php');
?>

<?php 
    include('layouts/menu.php')
?>

<?php 
    include('layouts/cookies.php')
?>
    <style>
        body,html {
            padding:0;
            margin:0;
            overscroll-behavior: none;
            background-color: black;
            overflow:hidden;
        }
        a:hover {
            text-decoration: underline;
        }
        a img.icon {
            display: inline-block;
            height: 1em;
            margin: 0 0 -0.1em 0.3em;
        }
    </style>
    <div class="qe-back translation" id="kenpo"><!--Que es Kenpo?-->
        <div class="lamina">
            <div class="ani1 contain">
                <div class="home-text">
                    <h2>
                        Matías Manchino
                    </h2>
                    <p>lalala</p>
                    <p>
                        <img loading="lazy" class="qe-img" src="img/soc-loto-blanco.jpg" alt="">
                        alallalal
                    </p>
                    <p class="ver-mas">
                        <button action="" class="ver-mas">
                            <a href="https://mapachinodev.com/kenpo"> Ver más</a>
                        </button>
                    </p>
                </div>

            </div>
        </div>
    </div>     
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.10.1/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/jsm/controls/OrbitControls.js"></script>

    <div id="container"></div>

    <!-- Enlaza tu archivo JavaScript externo -->
    <script src="tu_script.js"></script>
    
    
    <form  method="POST" action="email.php" id="formulario" class="ani1 formulario translation"> <!--Formulario de contacto-->
        <h2>Contactenos!</h2>
        <div class="formulario__grupo" id="grupo__nombre">
            <div class="formulario__input ">
                <input type="text" name="nombre" class="form__input" id="nombre" autocomplete="off"/>
                <label for="nombre" class="formu__label">Tu nombre</label>
                <i class="formulario__validacion-estado fa fa-times-circle"></i>
            </div>
            <p class="formulario__input-error">El nombre debe ser de no mas de digitos y debe contener letras</p>
        </div>
        <div class="formulario__grupo" id="grupo__mail">
            <div class="formulario__input ">
                <input type="email" name="mail" class="form__input" id="mail" autocomplete="off"/>
                <label for="mail" class="formu__label">Tu correo electronico</label>
                <i class="formulario__validacion-estado fa fa-times-circle"></i>
            </div>
            <p class="formulario__input-error">El correo solo puede contener letras, numeros, puntos, guiones y guion bajo.</p>
        </div>
        <div class="formulario__grupo" id="grupo__asunto">
            <div class="formulario__input ">
                <input type="text" name="asunto" class="form__input" id="asunto" autocomplete="off"/>
                <label for="asunto" class="formu__label">Asunto</label>
                <i class="formulario__validacion-estado fa fa-times-circle"></i>
            </div>
            <p class="formulario__input-error">El asunto no se puede extender mas de 40 caracteres y no esta permitido el uso de caracteres especiales.</p>
        </div>
        <div class="formulario__grupo" id="grupo__mensaje">
            <div class="formulario__input ">
                <input type="text" name="mensaje" class="form__input" id="mensaje" autocomplete="off"/>
                <label for="mensaje" class="formu__label">Tu mensaje</label>
                <i class="formulario__validacion-estado fa fa-times-circle"></i>
            </div>
            <p class="formulario__input-error">El mensaje no se puede extender mas de 300 caracteres y no esta permitido el uso de el uso de caracteres especiales.</p>
        </div>
        <div class="formu__mensaje" id="formu__mensaje">
            <i class="fa fa-exclamation-circle"> Error! No se ha podido enviar, intente nuevamente</i>
        </div>
        <div class="formulario__grupo formulario__grupo-btn-enviar">            
           <button type="submit" name="submit" class="formu__submit formu__btn">Enviar formulario</button>
           <p class="formulario__mensaje-exito" id="formulario__mensaje-exito">Tu mensaje ha sido enviado!</p>
        </div>
    </form>
    444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444
 <div class="info-popup" id="infoPopup">
    <div class="close-btn" onclick="toggleInfoPopup()">X</div>
    <p>
      Comunicado: En el día de la fecha informamos que provisoriamente no se encuentra en Sede Salta, ningún Instructor, Profesor o Cinturón Negro capacitado para dar clases y/o cursos tanto del estilo Byakuren Ken como del Sistema GAEP. La Sede Salta temporalmente queda a cargo del Sensei Claudio Abdala. De esta forma comunicamos públicamente lo que ha sido previamente establecido por la organización ESCUELA DE BYAKUREN KENPO y difundido a través de las organizaciones de las que forma parte y con las que mantiene vinculación.
      <!-- ... (resto del texto) ... -->
      Buenos Aires, 5 de enero de 2024.- Maestro Gerardo Seijo Fundador de la Escuela de Byakuren Kenpo Cofundador de la Confederación Latinoamericana de Kenpo
    </p>
  </div>
<?php 
    include('layouts/footer.php'); 
?>